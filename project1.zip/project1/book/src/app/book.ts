import { Pipe, PipeTransform } from '@angular/core';

export class Book {
    
    
    bookId:number;
    bookname:string;
    bookAuther:string;
    bookTitle:string;
    bookCategory:string;
    bookPublisherName:string;
    bookStatus:string;
    constructor(){}
}
