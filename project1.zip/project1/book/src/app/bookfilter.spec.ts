import { Bookfilter } from './bookfilter';

describe('Bookfilter', () => {
  it('should create an instance', () => {
    expect(new Bookfilter()).toBeTruthy();
  });
});
