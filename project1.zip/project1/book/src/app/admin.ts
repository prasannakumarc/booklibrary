export class Admin {

    adminId:number;
    email:string;
    password:string;

    constructor(){}

}
