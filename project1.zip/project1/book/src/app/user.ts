export class User {

    userId:number;
    firstName:string;
    lastName:string;
    userName:string;
    gender:string;
    email:string;
    password:string;

    constructor(){}

}
